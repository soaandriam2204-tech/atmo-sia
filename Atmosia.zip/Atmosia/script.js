// ===== 1. Récupérer les éléments de la page =====
const form = document.getElementById("search-form");
const cityInput = document.getElementById("city-input");
const message = document.getElementById("message");
const card = document.getElementById("weather-card");

const cityName = document.getElementById("city-name");
const temperature = document.getElementById("temperature");
const wind = document.getElementById("wind");
const humidity = document.getElementById("humidity");
const icon = document.getElementById("icon");
const description = document.getElementById("description");
const forecast = document.getElementById("forecast");

const themeToggle = document.getElementById("theme-toggle");
const locateBtn = document.getElementById("locate-btn");

// ===== 2. Mode sombre (avec mémoire) =====
function applyTheme(isDark) {
  if (isDark) {
    document.body.classList.add("dark");
    themeToggle.textContent = "☀️";
  } else {
    document.body.classList.remove("dark");
    themeToggle.textContent = "🌙";
  }
}

themeToggle.addEventListener("click", function () {
  const isDark = !document.body.classList.contains("dark");
  applyTheme(isDark);
  localStorage.setItem("atmosia-theme", isDark ? "dark" : "light");
});

// ===== 3. Quand on envoie le formulaire =====
form.addEventListener("submit", function (event) {
  event.preventDefault();
  const city = cityInput.value.trim();
  if (city) {
    getWeather(city);
  }
});

// ===== 4. Recherche par nom de ville =====
async function getWeather(city) {
  message.textContent = "Chargement...";
  card.classList.add("hidden");

  try {
    const geoUrl =
      "https://geocoding-api.open-meteo.com/v1/search?name=" +
      encodeURIComponent(city) +
      "&count=1&language=fr";

    const geoResponse = await fetch(geoUrl);
    const geoData = await geoResponse.json();

    if (!geoData.results || geoData.results.length === 0) {
      message.textContent = "Ville introuvable. Vérifie l'orthographe.";
      return;
    }

    const place = geoData.results[0];
    await getWeatherByCoords(place.latitude, place.longitude, place.name, place.country);

    localStorage.setItem("atmosia-city", city);
  } catch (error) {
    message.textContent = "Erreur de connexion. Réessaie plus tard.";
    console.error(error);
  }
}

// ===== 4 bis. Recherche par coordonnées =====
async function getWeatherByCoords(lat, lon, name, country) {
  try {
    const weatherUrl =
      "https://api.open-meteo.com/v1/forecast?latitude=" +
      lat +
      "&longitude=" +
      lon +
      "&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code" +
      "&daily=weather_code,temperature_2m_max,temperature_2m_min" +
      "&forecast_days=6" +
      "&timezone=auto";

    const weatherResponse = await fetch(weatherUrl);
    const weatherData = await weatherResponse.json();

    showWeather({ name: name, country: country }, weatherData.current);
    showForecast(weatherData.daily);
    message.textContent = "";
  } catch (error) {
    message.textContent = "Erreur de connexion. Réessaie plus tard.";
    console.error(error);
  }
}

// ===== 5. Afficher les résultats =====
function showWeather(place, current) {
  const info = getWeatherInfo(current.weather_code);

  cityName.textContent = place.country ? place.name + ", " + place.country : place.name;
  icon.textContent = info.icon;
  description.textContent = info.text;
  temperature.textContent = Math.round(current.temperature_2m) + "°C";
  wind.textContent = Math.round(current.wind_speed_10m) + " km/h";
  humidity.textContent = current.relative_humidity_2m + " %";

  setBackground(info.type);
  card.classList.remove("hidden");
}

// ===== 5 bis. Afficher la prévision sur 5 jours =====
function showForecast(daily) {
  forecast.innerHTML = "";

  // On commence à 1 pour sauter aujourd'hui (déjà affiché plus haut)
  for (let i = 1; i <= 5; i++) {
    const date = new Date(daily.time[i] + "T12:00:00");
    const dayName = date.toLocaleDateString("fr-FR", { weekday: "short" });
    const info = getWeatherInfo(daily.weather_code[i]);

    const dayBox = document.createElement("div");
    dayBox.className = "forecast-day";
    dayBox.innerHTML =
      "<span>" + dayName + "</span>" +
      '<span class="day-icon">' + info.icon + "</span>" +
      '<span class="day-max">' + Math.round(daily.temperature_2m_max[i]) + "°</span>" +
      '<span class="day-min">' + Math.round(daily.temperature_2m_min[i]) + "°</span>";

    forecast.appendChild(dayBox);
  }
}

// ===== 6. Codes météo : icône + description + type de fond =====
function getWeatherInfo(code) {
  if (code === 0) return { icon: "☀️", text: "Ciel dégagé", type: "clear" };
  if (code === 1) return { icon: "🌤️", text: "Plutôt dégagé", type: "clear" };
  if (code === 2) return { icon: "⛅", text: "Partiellement nuageux", type: "clouds" };
  if (code === 3) return { icon: "☁️", text: "Couvert", type: "clouds" };
  if (code === 45 || code === 48) return { icon: "🌫️", text: "Brouillard", type: "fog" };
  if (code >= 51 && code <= 57) return { icon: "🌦️", text: "Bruine", type: "rain" };
  if (code >= 61 && code <= 67) return { icon: "🌧️", text: "Pluie", type: "rain" };
  if (code >= 71 && code <= 77) return { icon: "❄️", text: "Neige", type: "snow" };
  if (code >= 80 && code <= 82) return { icon: "🌧️", text: "Averses", type: "rain" };
  if (code === 85 || code === 86) return { icon: "🌨️", text: "Averses de neige", type: "snow" };
  if (code >= 95) return { icon: "⛈️", text: "Orage", type: "storm" };
  return { icon: "🌡️", text: "Météo inconnue", type: "clear" };
}

// ===== 6 bis. Changer le fond du body =====
function setBackground(type) {
  const types = ["clear", "clouds", "fog", "rain", "snow", "storm"];

  types.forEach(function (t) {
    document.body.classList.remove("weather-" + t);
  });

  document.body.classList.add("weather-" + type);
}

// ===== 7. Bouton Ma position =====
locateBtn.addEventListener("click", function () {
  if (!navigator.geolocation) {
    message.textContent = "La géolocalisation n'est pas disponible sur cet appareil.";
    return;
  }

  message.textContent = "Recherche de ta position...";
  card.classList.add("hidden");

  navigator.geolocation.getCurrentPosition(
    function (position) {
      getWeatherByCoords(
        position.coords.latitude,
        position.coords.longitude,
        "Ma position",
        ""
      );
    },
    function () {
      message.textContent = "Position refusée ou indisponible. Autorise la localisation.";
    }
  );
});

// ===== 8. Au démarrage : retrouver thème et dernière ville =====
const savedTheme = localStorage.getItem("atmosia-theme");
if (savedTheme === "dark") {
  applyTheme(true);
}

const savedCity = localStorage.getItem("atmosia-city");
if (savedCity) {
  cityInput.value = savedCity;
  getWeather(savedCity);
}